/*
    Practice2Wildcards.java
    Практика #2: <? extends T> и <? super T> + зачем это нужно

    Коротко смысл:
    - ? extends T  (Producer)  => удобно читать как T, но почти нельзя добавлять
    - ? super T    (Consumer)  => удобно добавлять T, но читать можно только как Object

    Часто это объясняют правилом PECS:
    Producer Extends, Consumer Super.

    Ниже пример на списках чисел:
    - sum(...) читает числа и считает сумму => extends
    - addSomeIntegers(...) добавляет Integer => super
*/

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Practice2Wildcards {

    // "Producer": список производит (отдаёт) Number-ы.
    // Подходит List<Integer>, List<Double>, List<Number> и т.д.
    static double sumNumbers(List<? extends Number> numbers) {
        double sum = 0.0;

        // Мы уверены, что любой элемент — это Number (или его наследник),
        // поэтому читать можно спокойно.
        for (Number n : numbers) {
            sum += n.doubleValue();
        }

        // А вот добавлять нельзя, потому что реальный тип неизвестен:
        // numbers.add(123); // НЕ скомпилируется
        return sum;
    }

    // "Consumer": список потребляет (принимает) Integer.
    // Подходит List<Integer>, List<Number>, List<Object>.
    static void addSomeIntegers(List<? super Integer> dst) {
        // Мы гарантируем, что dst может принять Integer, потому что он Integer или выше.
        dst.add(10);
        dst.add(20);
        dst.add(30);

        // Читать как Integer нельзя: вдруг это List<Object>?
        // Поэтому при чтении получаем только Object.
        Object first = dst.get(0);
        System.out.println("Первый элемент после добавления (как Object): " + first);
    }

    /*
        Полезная реальная задача: копирование из источника в приёмник.
        Источник "производит" T => extends
        Приёмник "потребляет" T => super
    */
    static <T> void copy(List<? extends T> src, List<? super T> dst) {
        for (T item : src) {
            dst.add(item);
        }
    }

    public static void main(String[] args) {
        List<Integer> ints = Arrays.asList(1, 2, 3, 4);
        List<Double> doubles = Arrays.asList(1.5, 2.5, 3.5);

        System.out.println("sum(ints)    = " + sumNumbers(ints));
        System.out.println("sum(doubles) = " + sumNumbers(doubles));

        // super: добавляем Integer в список, который точно "не ниже" Integer
        List<Number> numbers = new ArrayList<>();
        addSomeIntegers(numbers);
        System.out.println("numbers = " + numbers);

        // Пример copy: копируем Integer в Object (это нормально)
        List<Integer> src = Arrays.asList(7, 8, 9);
        List<Object> dst = new ArrayList<>();
        copy(src, dst);
        System.out.println("dst после copy = " + dst);

        // И наоборот: скопировать Object в Integer нельзя (и это правильно).
        // List<Object> srcObj = Arrays.asList("x", "y");
        // List<Integer> dstInt = new ArrayList<>();
        // copy(srcObj, dstInt); // тут компилятор не даст ошибиться
    }
}
