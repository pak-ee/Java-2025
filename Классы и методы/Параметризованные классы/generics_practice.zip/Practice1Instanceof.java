/*
    Practice1Instanceof.java
    Практика #1: instanceof + параметризованные классы (generics)

    Важно: в Java generics работают со "стиранием типов" (type erasure).
    Это значит, что во время выполнения JVM НЕ знает, какой именно тип был у T:
    Wrapper<Integer> и Wrapper<String> становятся просто Wrapper.

    Поэтому выражение вида:
        if (w instanceof Wrapper<Integer>)
    НЕ скомпилируется.

    Но есть нормальные способы:
    1) Проверять "это Wrapper вообще" через Wrapper<?> или сырой Wrapper
    2) Проверять конкретный подкласс, который фиксирует тип в названии класса
    3) Проверять реальный объект, который лежит внутри (getItem() instanceof ...)
*/

public class Practice1Instanceof {

    // Обычная обёртка. Тип T существует на этапе компиляции, но не сохраняется в runtime.
    static class Wrapper<T> {
        private T item;

        public Wrapper(T item) {
            this.item = item;
        }

        public T getItem() {
            return item;
        }

        public void setItem(T item) {
            this.item = item;
        }

        @Override
        public String toString() {
            return "Wrapper{item=" + item + "}";
        }
    }

    /*
        Подкласс, где тип закреплён в самом классе.
        Тут уже можно делать:
            obj instanceof IntWrapper
        потому что это проверка конкретного класса, а не generic-параметра.
    */
    static class IntWrapper extends Wrapper<Integer> {
        public IntWrapper(Integer item) {
            super(item);
        }
    }

    public static void main(String[] args) {
        Wrapper<Integer> wi = new Wrapper<>(123);
        Wrapper<String> ws = new Wrapper<>("hello");
        IntWrapper iw = new IntWrapper(777);

        // 1) Проверяем "это Wrapper вообще?" — так можно.
        System.out.println("wi instanceof Wrapper<?> = " + (wi instanceof Wrapper<?>));
        System.out.println("ws instanceof Wrapper<?> = " + (ws instanceof Wrapper<?>));

        // 2) Нельзя проверять параметр типа напрямую — это не компилируется.
        //    Оставляю в комментарии, чтобы было видно "что именно нельзя".
        //
        // if (wi instanceof Wrapper<Integer>) {
        //     System.out.println("Это Wrapper<Integer>");
        // }

        // 3) Можно проверять подкласс, где тип закреплён на уровне класса
        System.out.println("iw instanceof IntWrapper = " + (iw instanceof IntWrapper));
        System.out.println("wi instanceof IntWrapper = " + (wi instanceof IntWrapper)); // false, это другой класс

        // 4) Можно проверить реальный объект внутри обёртки
        System.out.println("wi.getItem() instanceof Integer = " + (wi.getItem() instanceof Integer));
        System.out.println("ws.getItem() instanceof String  = " + (ws.getItem() instanceof String));

        // Ещё пример: если держим ссылку как Wrapper<?> (тип неизвестен),
        // можно хотя бы аккуратно выяснить, что лежит внутри.
        Wrapper<?> unknown = Math.random() > 0.5 ? wi : ws;
        System.out.println("unknown = " + unknown);

        Object inside = unknown.getItem(); // при Wrapper<?> мы получаем Object — это честно
        if (inside instanceof Integer) {
            System.out.println("Внутри unknown лежит Integer: " + inside);
        } else if (inside instanceof String) {
            System.out.println("Внутри unknown лежит String: " + inside);
        } else {
            System.out.println("Внутри unknown лежит что-то другое: " + inside);
        }

        // Итог: instanceof работает по классу, а generic-параметры в runtime уже стерты.
    }
}
