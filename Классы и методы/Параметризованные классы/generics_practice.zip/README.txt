Содержимое архива:
- Practice1Instanceof.java — практика #1 (instanceof + generics)
- Practice2Wildcards.java  — практика #2 (<? extends T> и <? super T>)

Как запустить (из папки с файлами):
javac Practice1Instanceof.java
java Practice1Instanceof

javac Practice2Wildcards.java
java Practice2Wildcards
